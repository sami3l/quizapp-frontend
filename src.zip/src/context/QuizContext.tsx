import React, { createContext, useState, useContext, ReactNode } from 'react';

export type QuestionType = 'multiple-choice' | 'true-false' | 'short-answer';

export interface Question {
  id: string;
  text: string;
  type: QuestionType;
  options?: string[];
  correctAnswer: string | string[];
  explanation?: string;
}

export interface Quiz {
  id: string;
  title: string;
  description: string;
  questions: Question[];
  createdBy: string;
  createdAt: Date;
}

export interface QuizAttempt {
  id: string;
  quizId: string;
  userId: string;
  answers: Record<string, string | string[]>;
  score: number;
  completedAt: Date;
}

interface QuizContextType {
  quizzes: Quiz[];
  userQuizzes: Quiz[];
  userAttempts: QuizAttempt[];
  currentQuiz: Quiz | null;
  createQuiz: (quiz: Omit<Quiz, 'id' | 'createdAt'>) => void;
  getQuizById: (id: string) => Quiz | undefined;
  submitQuizAttempt: (attempt: Omit<QuizAttempt, 'id' | 'score' | 'completedAt'>) => QuizAttempt;
}

const QuizContext = createContext<QuizContextType | undefined>(undefined);

export const useQuiz = () => {
  const context = useContext(QuizContext);
  if (context === undefined) {
    throw new Error('useQuiz must be used within a QuizProvider');
  }
  return context;
};

interface QuizProviderProps {
  children: ReactNode;
}

export const QuizProvider = ({ children }: QuizProviderProps) => {
  const [quizzes, setQuizzes] = useState<Quiz[]>([
    {
      id: '1',
      title: 'JavaScript Basics',
      description: 'Test your knowledge of JavaScript fundamentals',
      questions: [
        {
          id: 'q1',
          text: 'What is JavaScript?',
          type: 'multiple-choice',
          options: [
            'A programming language',
            'A markup language',
            'A styling language',
            'A database'
          ],
          correctAnswer: 'A programming language',
          explanation: 'JavaScript is a programming language that enables interactive web pages.'
        },
        {
          id: 'q2',
          text: 'Is JavaScript case-sensitive?',
          type: 'true-false',
          options: ['True', 'False'],
          correctAnswer: 'True',
          explanation: 'JavaScript is case-sensitive. For example, variables "myVar" and "myvar" are different.'
        }
      ],
      createdBy: '1',
      createdAt: new Date('2023-01-01')
    }
  ]);
  
  const [userAttempts, setUserAttempts] = useState<QuizAttempt[]>([]);
  const [currentQuiz, setCurrentQuiz] = useState<Quiz | null>(null);
  
  const userQuizzes = quizzes.filter(quiz => quiz.createdBy === '1');
  
  const createQuiz = (quizData: Omit<Quiz, 'id' | 'createdAt'>) => {
    const newQuiz: Quiz = {
      ...quizData,
      id: Date.now().toString(),
      createdAt: new Date()
    };
    
    setQuizzes([...quizzes, newQuiz]);
  };
  
  const getQuizById = (id: string) => {
    const quiz = quizzes.find(q => q.id === id);
    setCurrentQuiz(quiz || null);
    return quiz;
  };
  
  const submitQuizAttempt = (attemptData: Omit<QuizAttempt, 'id' | 'score' | 'completedAt'>) => {
    const quiz = quizzes.find(q => q.id === attemptData.quizId);
    
    if (!quiz) {
      throw new Error('Quiz not found');
    }
    
    let correctAnswers = 0;
    
    quiz.questions.forEach(question => {
      const userAnswer = attemptData.answers[question.id];
      if (Array.isArray(question.correctAnswer)) {
        if (Array.isArray(userAnswer) && 
            question.correctAnswer.length === userAnswer.length && 
            question.correctAnswer.every(a => userAnswer.includes(a))) {
          correctAnswers++;
        }
      } else if (userAnswer === question.correctAnswer) {
        correctAnswers++;
      }
    });
    
    const score = (correctAnswers / quiz.questions.length) * 100;
    
    const newAttempt: QuizAttempt = {
      id: Date.now().toString(),
      ...attemptData,
      score,
      completedAt: new Date()
    };
    
    setUserAttempts([...userAttempts, newAttempt]);
    
    return newAttempt;
  };
  
  return (
    <QuizContext.Provider value={{
      quizzes,
      userQuizzes,
      userAttempts,
      currentQuiz,
      createQuiz,
      getQuizById,
      submitQuizAttempt
    }}>
      {children}
    </QuizContext.Provider>
  );
};