import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuiz, QuestionType, Question } from '../context/QuizContext';
import { useAuth } from '../context/AuthContext';
import { PlusCircle, X, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';

const CreateQuizPage = () => {
  const { createQuiz } = useQuiz();
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [questions, setQuestions] = useState<Omit<Question, 'id'>[]>([
    {
      text: '',
      type: 'multiple-choice',
      options: ['', ''],
      correctAnswer: '',
      explanation: ''
    }
  ]);
  const [errors, setErrors] = useState<string[]>([]);
  
  const handleQuestionTypeChange = (index: number, type: QuestionType) => {
    const newQuestions = [...questions];
    
    if (type === 'multiple-choice') {
      newQuestions[index] = {
        ...newQuestions[index],
        type,
        options: newQuestions[index].options || ['', ''],
        correctAnswer: ''
      };
    } else if (type === 'true-false') {
      newQuestions[index] = {
        ...newQuestions[index],
        type,
        options: ['True', 'False'],
        correctAnswer: ''
      };
    } else {
      // Short answer
      newQuestions[index] = {
        ...newQuestions[index],
        type,
        options: undefined,
        correctAnswer: ''
      };
    }
    
    setQuestions(newQuestions);
  };
  
  const handleQuestionTextChange = (index: number, text: string) => {
    const newQuestions = [...questions];
    newQuestions[index].text = text;
    setQuestions(newQuestions);
  };
  
  const handleOptionChange = (questionIndex: number, optionIndex: number, value: string) => {
    const newQuestions = [...questions];
    if (!newQuestions[questionIndex].options) {
      newQuestions[questionIndex].options = [];
    }
    newQuestions[questionIndex].options![optionIndex] = value;
    setQuestions(newQuestions);
  };
  
  const handleCorrectAnswerChange = (questionIndex: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[questionIndex].correctAnswer = value;
    setQuestions(newQuestions);
  };
  
  const handleExplanationChange = (questionIndex: number, value: string) => {
    const newQuestions = [...questions];
    newQuestions[questionIndex].explanation = value;
    setQuestions(newQuestions);
  };
  
  const addOption = (questionIndex: number) => {
    const newQuestions = [...questions];
    if (!newQuestions[questionIndex].options) {
      newQuestions[questionIndex].options = [];
    }
    newQuestions[questionIndex].options!.push('');
    setQuestions(newQuestions);
  };
  
  const removeOption = (questionIndex: number, optionIndex: number) => {
    const newQuestions = [...questions];
    newQuestions[questionIndex].options!.splice(optionIndex, 1);
    setQuestions(newQuestions);
  };
  
  const addQuestion = () => {
    setQuestions([
      ...questions,
      {
        text: '',
        type: 'multiple-choice',
        options: ['', ''],
        correctAnswer: '',
        explanation: ''
      }
    ]);
  };
  
  const removeQuestion = (index: number) => {
    if (questions.length === 1) {
      return; // Don't remove the last question
    }
    const newQuestions = [...questions];
    newQuestions.splice(index, 1);
    setQuestions(newQuestions);
  };
  
  const moveQuestionUp = (index: number) => {
    if (index === 0) return;
    const newQuestions = [...questions];
    [newQuestions[index - 1], newQuestions[index]] = [newQuestions[index], newQuestions[index - 1]];
    setQuestions(newQuestions);
  };
  
  const moveQuestionDown = (index: number) => {
    if (index === questions.length - 1) return;
    const newQuestions = [...questions];
    [newQuestions[index], newQuestions[index + 1]] = [newQuestions[index + 1], newQuestions[index]];
    setQuestions(newQuestions);
  };
  
  const validateForm = () => {
    const newErrors: string[] = [];
    
    if (!title) newErrors.push('Quiz title is required');
    if (!description) newErrors.push('Quiz description is required');
    
    questions.forEach((question, index) => {
      if (!question.text) {
        newErrors.push(`Question ${index + 1} text is required`);
      }
      
      if (question.type === 'multiple-choice' || question.type === 'true-false') {
        if (!question.options || question.options.length < 2) {
          newErrors.push(`Question ${index + 1} must have at least 2 options`);
        } else if (question.options.some(opt => !opt)) {
          newErrors.push(`All options in question ${index + 1} must be filled`);
        }
        
        if (!question.correctAnswer) {
          newErrors.push(`Question ${index + 1} must have a correct answer selected`);
        }
      } else if (question.type === 'short-answer') {
        if (!question.correctAnswer) {
          newErrors.push(`Question ${index + 1} must have a correct answer`);
        }
      }
    });
    
    setErrors(newErrors);
    return newErrors.length === 0;
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    
    if (!validateForm()) return;
    
    // Transform questions to include IDs
    const questionsWithIds = questions.map((q) => ({
      ...q,
      id: Date.now().toString() + Math.random().toString(36).substr(2, 9),
    }));
    
    createQuiz({
      title,
      description,
      questions: questionsWithIds,
      createdBy: user?.id || 'unknown',
    });
    
    navigate('/dashboard');
  };
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900">Create a New Quiz</h1>
          <p className="text-gray-600">Design your quiz with various question types</p>
        </div>
        
        {errors.length > 0 && (
          <div className="bg-red-50 border border-red-200 text-red-800 rounded-lg p-4 mb-6">
            <div className="flex">
              <AlertCircle className="h-5 w-5 text-red-600 mr-2" />
              <div>
                <h3 className="font-medium">Please fix the following errors:</h3>
                <ul className="mt-1 list-disc list-inside">
                  {errors.map((error, index) => (
                    <li key={index}>{error}</li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        )}
        
        <form onSubmit={handleSubmit} className="space-y-8">
          {/* Quiz Details */}
          <div className="bg-white rounded-xl shadow-sm p-6">
            <h2 className="text-xl font-semibold mb-4">Quiz Details</h2>
            
            <div className="space-y-4">
              <div>
                <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-1">
                  Quiz Title
                </label>
                <input
                  type="text"
                  id="title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="e.g., JavaScript Fundamentals"
                />
              </div>
              
              <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700 mb-1">
                  Description
                </label>
                <textarea
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Describe what this quiz is about..."
                ></textarea>
              </div>
            </div>
          </div>
          
          {/* Questions */}
          <div className="space-y-6">
            <h2 className="text-xl font-semibold">Questions</h2>
            
            {questions.map((question, qIndex) => (
              <div key={qIndex} className="bg-white rounded-xl shadow-sm p-6">
                <div className="flex justify-between items-start mb-4">
                  <h3 className="text-lg font-medium">Question {qIndex + 1}</h3>
                  <div className="flex space-x-2">
                    <button
                      type="button"
                      onClick={() => moveQuestionUp(qIndex)}
                      disabled={qIndex === 0}
                      className={`p-1 rounded-full ${
                        qIndex === 0 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <ChevronUp className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => moveQuestionDown(qIndex)}
                      disabled={qIndex === questions.length - 1}
                      className={`p-1 rounded-full ${
                        qIndex === questions.length - 1 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600 hover:bg-gray-100'
                      }`}
                    >
                      <ChevronDown className="h-5 w-5" />
                    </button>
                    <button
                      type="button"
                      onClick={() => removeQuestion(qIndex)}
                      className="p-1 rounded-full text-red-600 hover:bg-red-50"
                      title="Remove Question"
                    >
                      <X className="h-5 w-5" />
                    </button>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Question Type
                    </label>
                    <select
                      value={question.type}
                      onChange={(e) => handleQuestionTypeChange(qIndex, e.target.value as QuestionType)}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                    >
                      <option value="multiple-choice">Multiple Choice</option>
                      <option value="true-false">True/False</option>
                      <option value="short-answer">Short Answer</option>
                    </select>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Question Text
                    </label>
                    <textarea
                      value={question.text}
                      onChange={(e) => handleQuestionTextChange(qIndex, e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Enter your question here..."
                    ></textarea>
                  </div>
                  
                  {(question.type === 'multiple-choice' || question.type === 'true-false') && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Options
                      </label>
                      
                      <div className="space-y-2">
                        {question.options && question.options.map((option, oIndex) => (
                          <div key={oIndex} className="flex items-center space-x-2">
                            <input
                              type="radio"
                              name={`correct-${qIndex}`}
                              checked={question.correctAnswer === option}
                              onChange={() => handleCorrectAnswerChange(qIndex, option)}
                              className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                            />
                            <input
                              type="text"
                              value={option}
                              onChange={(e) => handleOptionChange(qIndex, oIndex, e.target.value)}
                              className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                              placeholder={`Option ${oIndex + 1}`}
                            />
                            {question.type === 'multiple-choice' && question.options && question.options.length > 2 && (
                              <button
                                type="button"
                                onClick={() => removeOption(qIndex, oIndex)}
                                className="p-1 rounded-full text-red-600 hover:bg-red-50"
                                title="Remove Option"
                              >
                                <X className="h-5 w-5" />
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                      
                      {question.type === 'multiple-choice' && (
                        <button
                          type="button"
                          onClick={() => addOption(qIndex)}
                          className="mt-2 flex items-center text-sm text-blue-600 hover:text-blue-800"
                        >
                          <PlusCircle className="h-4 w-4 mr-1" />
                          Add Option
                        </button>
                      )}
                    </div>
                  )}
                  
                  {question.type === 'short-answer' && (
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Correct Answer
                      </label>
                      <input
                        type="text"
                        value={typeof question.correctAnswer === 'string' ? question.correctAnswer : ''}
                        onChange={(e) => handleCorrectAnswerChange(qIndex, e.target.value)}
                        className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Enter the correct answer"
                      />
                    </div>
                  )}
                  
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Explanation (Optional)
                    </label>
                    <textarea
                      value={question.explanation || ''}
                      onChange={(e) => handleExplanationChange(qIndex, e.target.value)}
                      rows={2}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      placeholder="Explain why this answer is correct..."
                    ></textarea>
                  </div>
                </div>
              </div>
            ))}
            
            <button
              type="button"
              onClick={addQuestion}
              className="flex items-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
            >
              <PlusCircle className="h-5 w-5 mr-2" />
              Add Question
            </button>
          </div>
          
          <div className="pt-4 pb-12">
            <button
              type="submit"
              className="px-6 py-3 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
            >
              {isAuthenticated ? 'Create Quiz' : 'Sign in to Create Quiz'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default CreateQuizPage;