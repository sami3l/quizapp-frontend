import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuiz } from '../context/QuizContext';
import { useAuth } from '../context/AuthContext';
import { PlusCircle, Edit, Trash2, BarChart, Clock, Award, User } from 'lucide-react';

type DashboardTab = 'myQuizzes' | 'attempts' | 'analytics';

const DashboardPage = () => {
  const { userQuizzes, userAttempts } = useQuiz();
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<DashboardTab>('myQuizzes');
  
  if (!user) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-800 mb-4">You need to be logged in</h2>
          <p className="text-gray-600 mb-6">Please sign in to access your dashboard</p>
          <Link
            to="/auth"
            className="px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Sign In
          </Link>
        </div>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600">Manage your quizzes and see your progress</p>
      </div>
      
      {/* User Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm mb-1">Created Quizzes</p>
              <h3 className="text-3xl font-bold text-gray-900">{userQuizzes.length}</h3>
            </div>
            <div className="rounded-full bg-purple-100 p-3">
              <PlusCircle className="h-6 w-6 text-purple-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm mb-1">Completed Quizzes</p>
              <h3 className="text-3xl font-bold text-gray-900">{userAttempts.length}</h3>
            </div>
            <div className="rounded-full bg-blue-100 p-3">
              <Award className="h-6 w-6 text-blue-600" />
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-xl shadow-sm p-6">
          <div className="flex items-start justify-between">
            <div>
              <p className="text-gray-500 text-sm mb-1">Average Score</p>
              <h3 className="text-3xl font-bold text-gray-900">
                {userAttempts.length > 0 
                  ? `${Math.round(userAttempts.reduce((acc, curr) => acc + curr.score, 0) / userAttempts.length)}%` 
                  : 'N/A'}
              </h3>
            </div>
            <div className="rounded-full bg-green-100 p-3">
              <BarChart className="h-6 w-6 text-green-600" />
            </div>
          </div>
        </div>
      </div>
      
      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex space-x-8">
          <button
            onClick={() => setActiveTab('myQuizzes')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'myQuizzes'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            My Quizzes
          </button>
          <button
            onClick={() => setActiveTab('attempts')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'attempts'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Quiz Attempts
          </button>
          <button
            onClick={() => setActiveTab('analytics')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'analytics'
                ? 'border-blue-600 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Analytics
          </button>
        </nav>
      </div>
      
      {/* Content Based on Active Tab */}
      <div className="mb-8">
        {activeTab === 'myQuizzes' && (
          <div>
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-xl font-semibold text-gray-900">My Quizzes</h2>
              <Link
                to="/create-quiz"
                className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <PlusCircle className="h-4 w-4 mr-2" />
                Create New Quiz
              </Link>
            </div>
            
            {userQuizzes.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {userQuizzes.map(quiz => (
                  <div key={quiz.id} className="bg-white rounded-xl shadow-sm overflow-hidden group">
                    <div className="p-6">
                      <h3 className="text-xl font-semibold mb-2 text-gray-800">{quiz.title}</h3>
                      <p className="text-gray-600 mb-4 line-clamp-2">{quiz.description}</p>
                      <div className="flex items-center text-gray-500 mb-4">
                        <Clock className="h-4 w-4 mr-1" />
                        <span className="text-sm">{quiz.questions.length} questions</span>
                      </div>
                      <div className="flex space-x-2">
                        <Link
                          to={`/quiz/${quiz.id}`}
                          className="flex-1 text-center py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                        >
                          View
                        </Link>
                        <button
                          className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                          title="Edit Quiz"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          className="p-2 text-gray-500 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                          title="Delete Quiz"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-xl">
                <PlusCircle className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-800 mb-2">No quizzes yet</h3>
                <p className="text-gray-600 mb-6">Create your first quiz to get started</p>
                <Link
                  to="/create-quiz"
                  className="px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Create Quiz
                </Link>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'attempts' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">My Quiz Attempts</h2>
            
            {userAttempts.length > 0 ? (
              <div className="bg-white shadow-sm rounded-xl overflow-hidden">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Quiz
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Date
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Score
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Actions
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {userAttempts.map(attempt => {
                      const quiz = userQuizzes.find(q => q.id === attempt.quizId);
                      return (
                        <tr key={attempt.id}>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm font-medium text-gray-900">
                              {quiz ? quiz.title : 'Unknown Quiz'}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="text-sm text-gray-500">
                              {new Date(attempt.completedAt).toLocaleDateString()}
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                              attempt.score >= 70 
                                ? 'bg-green-100 text-green-800' 
                                : attempt.score >= 40 
                                ? 'bg-yellow-100 text-yellow-800' 
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {Math.round(attempt.score)}%
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            <Link
                              to={`/results/${attempt.id}`}
                              className="text-blue-600 hover:text-blue-900"
                            >
                              View Results
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="text-center py-12 bg-gray-50 rounded-xl">
                <Award className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-medium text-gray-800 mb-2">No quiz attempts yet</h3>
                <p className="text-gray-600 mb-6">Take a quiz to see your results here</p>
                <Link
                  to="/"
                  className="px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Browse Quizzes
                </Link>
              </div>
            )}
          </div>
        )}
        
        {activeTab === 'analytics' && (
          <div>
            <h2 className="text-xl font-semibold text-gray-900 mb-6">Analytics</h2>
            
            <div className="bg-white shadow-sm rounded-xl p-6 text-center">
              <BarChart className="h-16 w-16 text-gray-400 mx-auto mb-4" />
              <h3 className="text-xl font-medium text-gray-800 mb-2">Analytics Coming Soon</h3>
              <p className="text-gray-600">
                Detailed analytics for your quizzes and attempts will be available in the next update.
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default DashboardPage;