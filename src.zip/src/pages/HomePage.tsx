import React from 'react';
import { Link } from 'react-router-dom';
import { useQuiz } from '../context/QuizContext';
import { BookOpen, CheckCircle, Clock, Award } from 'lucide-react';

const HomePage = () => {
  const { quizzes } = useQuiz();
  
  return (
    <div className="flex flex-col">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-blue-600 to-purple-700 text-white py-20 px-4">
        <div className="container mx-auto max-w-4xl text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-6 leading-tight">
            Create Interactive Quizzes with Automatic Correction
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-blue-100">
            Engage your audience with interactive quizzes that provide instant feedback and detailed analytics.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link
              to="/create-quiz"
              className="px-8 py-3 bg-white text-blue-700 font-semibold rounded-lg shadow-lg hover:bg-blue-50 transition-colors"
            >
              Create a Quiz
            </Link>
            <Link
              to="/auth"
              className="px-8 py-3 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-blue-700 transition-colors"
            >
              Sign Up for Free
            </Link>
          </div>
        </div>
      </section>
      
      {/* Features Section */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Why Choose QuizGenius?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="rounded-full bg-blue-100 w-14 h-14 flex items-center justify-center mb-6">
                <BookOpen className="h-6 w-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Create Engaging Quizzes</h3>
              <p className="text-gray-600">
                Build quizzes with multiple question types including multiple choice, true/false, and short answers.
              </p>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="rounded-full bg-green-100 w-14 h-14 flex items-center justify-center mb-6">
                <CheckCircle className="h-6 w-6 text-green-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Automatic Correction</h3>
              <p className="text-gray-600">
                Save time with instant automatic correction and detailed feedback for participants.
              </p>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-xl shadow-sm hover:shadow-md transition-shadow">
              <div className="rounded-full bg-purple-100 w-14 h-14 flex items-center justify-center mb-6">
                <Award className="h-6 w-6 text-purple-600" />
              </div>
              <h3 className="text-xl font-semibold mb-3 text-gray-800">Comprehensive Dashboard</h3>
              <p className="text-gray-600">
                Track performance with detailed analytics and insights on quiz results.
              </p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Featured Quizzes */}
      <section className="py-16 px-4 bg-gray-50">
        <div className="container mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Featured Quizzes</h2>
          
          {quizzes.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {quizzes.map(quiz => (
                <div key={quiz.id} className="bg-white rounded-xl shadow-sm hover:shadow-md transition-shadow overflow-hidden">
                  <div className="p-6">
                    <h3 className="text-xl font-semibold mb-2 text-gray-800">{quiz.title}</h3>
                    <p className="text-gray-600 mb-4">{quiz.description}</p>
                    <div className="flex items-center text-gray-500 mb-4">
                      <Clock className="h-4 w-4 mr-1" />
                      <span className="text-sm">{quiz.questions.length} questions</span>
                    </div>
                    <Link
                      to={`/quiz/${quiz.id}`}
                      className="block w-full text-center py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
                    >
                      Take Quiz
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center text-gray-600">
              <p>No quizzes available at the moment. Be the first to create one!</p>
              <Link
                to="/create-quiz"
                className="inline-block mt-4 px-6 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
              >
                Create a Quiz
              </Link>
            </div>
          )}
        </div>
      </section>
      
      {/* CTA Section */}
      <section className="py-16 px-4 bg-gradient-to-br from-purple-700 to-blue-600 text-white">
        <div className="container mx-auto text-center max-w-3xl">
          <h2 className="text-3xl font-bold mb-6">Ready to Create Your First Quiz?</h2>
          <p className="text-xl mb-8 text-blue-100">
            Join thousands of educators and trainers who are making assessment more engaging.
          </p>
          <Link
            to="/auth"
            className="px-8 py-3 bg-white text-blue-700 font-semibold rounded-lg shadow-lg hover:bg-blue-50 transition-colors"
          >
            Get Started Now
          </Link>
        </div>
      </section>
    </div>
  );
};

export default HomePage;