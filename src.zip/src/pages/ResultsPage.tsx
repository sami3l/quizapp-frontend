import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { useQuiz, Question } from '../context/QuizContext';
import { useAuth } from '../context/AuthContext';
import { CheckCircle, XCircle, AlertCircle, Download, Share2, Award, ArrowLeft } from 'lucide-react';

const ResultsPage = () => {
  const { id } = useParams<{ id: string }>();
  const { userAttempts, quizzes } = useQuiz();
  const { isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [attempt, setAttempt] = useState(userAttempts.find(a => a.id === id));
  const [quiz, setQuiz] = useState(attempt ? quizzes.find(q => q.id === attempt.quizId) : undefined);
  
  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/auth');
      return;
    }
    
    setAttempt(userAttempts.find(a => a.id === id));
    if (attempt) {
      setQuiz(quizzes.find(q => q.id === attempt.quizId));
    }
  }, [id, userAttempts, quizzes, isAuthenticated, navigate, attempt]);
  
  if (!attempt || !quiz) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">Results not found</h2>
          <p className="text-gray-600 mb-6">The quiz results you're looking for don't exist or have been removed.</p>
          <Link
            to="/dashboard"
            className="px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Go to Dashboard
          </Link>
        </div>
      </div>
    );
  }
  
  const getScoreClass = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };
  
  const isCorrect = (question: Question, userAnswer: string | string[]) => {
    if (Array.isArray(question.correctAnswer)) {
      return Array.isArray(userAnswer) && 
        question.correctAnswer.length === userAnswer.length && 
        question.correctAnswer.every(a => userAnswer.includes(a));
    } 
    return userAnswer === question.correctAnswer;
  };
  
  // Calculate stats
  const totalQuestions = quiz.questions.length;
  const correctAnswers = quiz.questions.filter(q => isCorrect(q, attempt.answers[q.id])).length;
  const incorrectAnswers = totalQuestions - correctAnswers;
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <Link
          to="/dashboard"
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          Back to Dashboard
        </Link>
        
        <div className="bg-white rounded-xl shadow-sm overflow-hidden mb-8">
          {/* Result Header */}
          <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8">
            <h1 className="text-2xl font-bold mb-2">{quiz.title}</h1>
            <p className="text-blue-100 mb-6">{quiz.description}</p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-4xl font-bold mb-1 text-white">{Math.round(attempt.score)}%</div>
                <div className="text-blue-100">Your Score</div>
              </div>
              
              <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-4xl font-bold mb-1 text-white">{correctAnswers}</div>
                <div className="text-blue-100">Correct Answers</div>
              </div>
              
              <div className="bg-white/10 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-4xl font-bold mb-1 text-white">{totalQuestions}</div>
                <div className="text-blue-100">Total Questions</div>
              </div>
            </div>
          </div>
          
          {/* Actions */}
          <div className="border-b border-gray-200 px-6 py-4 flex flex-wrap gap-2">
            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
              <Download className="h-4 w-4 mr-2" />
              Download PDF
            </button>
            <button className="flex items-center px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
              <Share2 className="h-4 w-4 mr-2" />
              Share Results
            </button>
            <Link 
              to={`/quiz/${quiz.id}`} 
              className="flex items-center px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
            >
              <Award className="h-4 w-4 mr-2" />
              Retake Quiz
            </Link>
          </div>
          
          {/* Question Reviews */}
          <div className="p-6">
            <h2 className="text-xl font-semibold mb-6">Question Review</h2>
            
            <div className="space-y-8">
              {quiz.questions.map((question, index) => {
                const userAnswer = attempt.answers[question.id];
                const correct = isCorrect(question, userAnswer);
                
                return (
                  <div key={question.id} className="border border-gray-200 rounded-lg overflow-hidden">
                    <div className={`p-4 ${correct ? 'bg-green-50' : 'bg-red-50'}`}>
                      <div className="flex justify-between items-start">
                        <h3 className="text-lg font-medium">Question {index + 1}</h3>
                        {correct ? (
                          <div className="flex items-center text-green-600">
                            <CheckCircle className="h-5 w-5 mr-1" />
                            <span>Correct</span>
                          </div>
                        ) : (
                          <div className="flex items-center text-red-600">
                            <XCircle className="h-5 w-5 mr-1" />
                            <span>Incorrect</span>
                          </div>
                        )}
                      </div>
                      <p className="mt-2">{question.text}</p>
                    </div>
                    
                    <div className="p-4 bg-white">
                      <div className="mb-4">
                        <div className="font-medium text-gray-700 mb-1">Your Answer:</div>
                        <div className={correct ? 'text-green-600' : 'text-red-600'}>
                          {typeof userAnswer === 'string' ? userAnswer : userAnswer?.join(', ') || 'No answer provided'}
                        </div>
                      </div>
                      
                      {!correct && (
                        <div className="mb-4">
                          <div className="font-medium text-gray-700 mb-1">Correct Answer:</div>
                          <div className="text-green-600">
                            {Array.isArray(question.correctAnswer) 
                              ? question.correctAnswer.join(', ') 
                              : question.correctAnswer}
                          </div>
                        </div>
                      )}
                      
                      {question.explanation && (
                        <div>
                          <div className="font-medium text-gray-700 mb-1">Explanation:</div>
                          <div className="text-gray-600 bg-gray-50 p-3 rounded">
                            {question.explanation}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultsPage;