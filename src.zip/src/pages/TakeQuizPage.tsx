import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuiz, Question } from '../context/QuizContext';
import { useAuth } from '../context/AuthContext';
import { Clock, AlertCircle, ArrowRight, CheckCircle } from 'lucide-react';

const TakeQuizPage = () => {
  const { id } = useParams<{ id: string }>();
  const { getQuizById, submitQuizAttempt } = useQuiz();
  const { user, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  
  const [quiz, setQuiz] = useState<ReturnType<typeof getQuizById>>();
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string | string[]>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  useEffect(() => {
    if (!id) {
      setError('Quiz not found');
      setLoading(false);
      return;
    }
    
    const quizData = getQuizById(id);
    setQuiz(quizData);
    
    if (!quizData) {
      setError('Quiz not found');
    }
    
    // Initialize answers object
    if (quizData) {
      const initialAnswers: Record<string, string | string[]> = {};
      quizData.questions.forEach((q) => {
        initialAnswers[q.id] = '';
      });
      setAnswers(initialAnswers);
      
      // Set timer if needed (5 minutes per question)
      // setTimeLeft(quizData.questions.length * 300);
    }
    
    setLoading(false);
  }, [id, getQuizById]);
  
  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers({
      ...answers,
      [questionId]: value,
    });
  };
  
  const handleNextQuestion = () => {
    if (currentQuestion < (quiz?.questions.length || 0) - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };
  
  const handlePrevQuestion = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };
  
  const handleSubmit = () => {
    if (!quiz || !isAuthenticated) return;
    
    setSubmitting(true);
    
    try {
      const attempt = submitQuizAttempt({
        quizId: quiz.id,
        userId: user?.id || 'anonymous',
        answers,
      });
      
      navigate(`/results/${attempt.id}`);
    } catch (err) {
      setError('Failed to submit quiz. Please try again.');
      setSubmitting(false);
    }
  };
  
  if (loading) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600">Loading quiz...</p>
        </div>
      </div>
    );
  }
  
  if (error || !quiz) {
    return (
      <div className="min-h-[calc(100vh-64px)] flex items-center justify-center p-4">
        <div className="text-center">
          <AlertCircle className="h-12 w-12 text-red-600 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-800 mb-2">{error || 'Quiz not found'}</h2>
          <p className="text-gray-600 mb-6">The quiz you're looking for doesn't exist or has been removed.</p>
          <button
            onClick={() => navigate('/')}
            className="px-5 py-2 bg-blue-600 text-white font-medium rounded-lg hover:bg-blue-700 transition-colors"
          >
            Back to Home
          </button>
        </div>
      </div>
    );
  }
  
  const question = quiz.questions[currentQuestion];
  
  return (
    <div className="container mx-auto px-4 py-8">
      <div className="max-w-3xl mx-auto bg-white rounded-xl shadow-sm overflow-hidden">
        {/* Quiz Header */}
        <div className="bg-blue-600 text-white p-6">
          <h1 className="text-2xl font-bold mb-2">{quiz.title}</h1>
          <p className="text-blue-100">{quiz.description}</p>
          
          <div className="flex justify-between items-center mt-4">
            <div className="flex items-center text-blue-100">
              <Clock className="h-4 w-4 mr-1" />
              <span>{quiz.questions.length} questions</span>
            </div>
            
            <div className="bg-blue-700 rounded-full px-3 py-1 text-sm">
              Question {currentQuestion + 1} of {quiz.questions.length}
            </div>
          </div>
        </div>
        
        {/* Progress Bar */}
        <div className="bg-gray-100 h-2">
          <div
            className="bg-blue-600 h-2 transition-all duration-300 ease-in-out"
            style={{ width: `${((currentQuestion + 1) / quiz.questions.length) * 100}%` }}
          ></div>
        </div>
        
        {/* Question Content */}
        <div className="p-6">
          <h2 className="text-xl font-semibold mb-6">{question.text}</h2>
          
          <div className="space-y-3 mb-8">
            {question.type === 'multiple-choice' && question.options && (
              <div className="space-y-3">
                {question.options.map((option, index) => (
                  <label
                    key={index}
                    className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                      answers[question.id] === option
                        ? 'border-blue-600 bg-blue-50 text-blue-700'
                        : 'border-gray-200 hover:border-blue-300'
                    }`}
                  >
                    <input
                      type="radio"
                      name={`question-${question.id}`}
                      value={option}
                      checked={answers[question.id] === option}
                      onChange={() => handleAnswerChange(question.id, option)}
                      className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                    />
                    <span className="ml-3">{option}</span>
                  </label>
                ))}
              </div>
            )}
            
            {question.type === 'true-false' && (
              <div className="space-y-3">
                <label
                  className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                    answers[question.id] === 'True'
                      ? 'border-blue-600 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <input
                    type="radio"
                    name={`question-${question.id}`}
                    value="True"
                    checked={answers[question.id] === 'True'}
                    onChange={() => handleAnswerChange(question.id, 'True')}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-3">True</span>
                </label>
                
                <label
                  className={`flex items-center p-4 border rounded-lg cursor-pointer transition-colors ${
                    answers[question.id] === 'False'
                      ? 'border-blue-600 bg-blue-50 text-blue-700'
                      : 'border-gray-200 hover:border-blue-300'
                  }`}
                >
                  <input
                    type="radio"
                    name={`question-${question.id}`}
                    value="False"
                    checked={answers[question.id] === 'False'}
                    onChange={() => handleAnswerChange(question.id, 'False')}
                    className="h-4 w-4 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-3">False</span>
                </label>
              </div>
            )}
            
            {question.type === 'short-answer' && (
              <div>
                <textarea
                  value={answers[question.id] as string || ''}
                  onChange={(e) => handleAnswerChange(question.id, e.target.value)}
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  placeholder="Enter your answer here..."
                ></textarea>
              </div>
            )}
          </div>
          
          {/* Navigation Buttons */}
          <div className="flex justify-between">
            <button
              onClick={handlePrevQuestion}
              disabled={currentQuestion === 0}
              className={`px-4 py-2 rounded-lg ${
                currentQuestion === 0
                  ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
                  : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
              }`}
            >
              Previous
            </button>
            
            {currentQuestion < quiz.questions.length - 1 ? (
              <button
                onClick={handleNextQuestion}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center"
              >
                Next
                <ArrowRight className="h-4 w-4 ml-1" />
              </button>
            ) : (
              <button
                onClick={handleSubmit}
                disabled={submitting || !isAuthenticated}
                className={`px-6 py-2 rounded-lg flex items-center ${
                  !isAuthenticated
                    ? 'bg-gray-300 text-gray-600 cursor-not-allowed'
                    : submitting
                    ? 'bg-blue-400 cursor-not-allowed'
                    : 'bg-green-600 text-white hover:bg-green-700'
                }`}
              >
                {submitting ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Submitting...
                  </>
                ) : (
                  <>
                    <CheckCircle className="h-4 w-4 mr-1" />
                    Submit Quiz
                  </>
                )}
              </button>
            )}
          </div>
          
          {!isAuthenticated && currentQuestion === quiz.questions.length - 1 && (
            <div className="mt-4 text-center text-sm text-red-600">
              You need to sign in to submit the quiz
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default TakeQuizPage;